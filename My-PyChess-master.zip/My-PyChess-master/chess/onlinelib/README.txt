In this folder we declare the 'onlinelib' module. This implements all of clients online gamemode related stuff.
This module is used by online.py

__init__.py - Defines two main functions, chess() to manage chess board and lobby() to manage lobby
utils.py - Define all important utilities for __init__.py. Mostly Gui related.
sockutils.py - As the name suggests, define all utility funcions for socket related stuff.

For more docmentation of the variables used and such, check docs.txt