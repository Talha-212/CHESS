A few important modules are placed here, they are handy thoughout the codebase. 

These are:

loader.py - Load all fonts for each script, put them into their respective classes
sound.py - Load all sounds, define functions for easy sound playback
utils.py - Contains general utility functions, mostly GUI related.